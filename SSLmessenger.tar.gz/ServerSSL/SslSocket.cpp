#include "SslSocket.h"

SslSocket::SslSocket()
{
    connect(this, &SslSocket::encrypted, [&]() {
       emit signal_encrypted();
    });

    connect(this, &SslSocket::readyRead, [&]() {
        emit signal_ReadyRead(this);
    });

    connect(this, &SslSocket::stateChanged, [&](int S) {
        emit signal_stateChanged(this, S);
    });
}
