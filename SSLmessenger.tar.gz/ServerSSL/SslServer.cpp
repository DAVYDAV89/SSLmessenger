#include "SslServer.h"
#include "SslSocket.h"
#include <QProcess>
#include <QFile>
#include <QDebug>

SslServer::SslServer()
{

}

bool SslServer::startServer(quint16 port)
{

    QString program = "openssl";
    QString arg("req -x509 -newkey rsa:1024 -keyout server.key -nodes -days 365 -out server.crt -batch");
    QStringList arguments = arg.split(' ', QString::SkipEmptyParts);

    QProcess prg(this);
    prg.execute(program, arguments);

    return listen(QHostAddress::Any, port);
}

void SslServer::incomingConnection(qintptr handle)
{
    auto *serverSocket = new SslSocket;

    if (serverSocket->setSocketDescriptor(handle)) {
        qDebug() << "Client connected with handle: " << handle;

        QFile crt_file("server.crt");
        if(crt_file.open(QIODevice::ReadOnly))
        {
            QByteArray crt_data = crt_file.readAll();
            crt_file.close();
            QSslCertificate cert(crt_data);

            if(cert.expiryDate() >= QDateTime::currentDateTime())
            {
                serverSocket->setPrivateKey("server.key");
                serverSocket->setLocalCertificate("server.crt");

                connect(serverSocket, &SslSocket::encrypted, [&]()
                {
                    qDebug() << "Server encrypted";

                });

                connect(serverSocket, &SslSocket::signal_ReadyRead, [&](SslSocket *S)
                {
                    QTextStream T(S);
                    auto text = T.readAll();

                    for (auto i : mSocket){
                        QTextStream K(i);
                        K << text;
                        i->flush();
                    }
                });

                connect(serverSocket, &SslSocket::signal_stateChanged, [&](SslSocket *S, int ST)
                {
                    qDebug() << "Server: stateChanged "
                             << S->socketDescriptor();

                    if (ST == QTcpSocket::UnconnectedState){
                        qDebug() << "UnconnectedState with handel"
                                 << S->socketDescriptor();

                        mSocket.removeOne(S);
                        for (auto i : mSocket){
                            QTextStream K(i);
                            K << "Server: client "
                              << S->socketDescriptor()
                              << "is disconnected...";
                            i->flush();
                        }
                    }
                });

                serverSocket->startServerEncryption();
            }
        }

        else
        {
            delete serverSocket;
        }
    }
    else
    {
        delete serverSocket;
    }

    mSocket << serverSocket;

    for (auto i : mSocket) {
        QTextStream T(i);
        T << "Server: Connected " << handle;
        i->flush();
    }
}
