#ifndef SSLSERVER_H
#define SSLSERVER_H

#include <QTcpServer>

class SslSocket;

class SslServer : public QTcpServer
{
public:
    SslServer();
    bool startServer(quint16 port);

protected:
    void incomingConnection(qintptr handle);
private:
    QList<SslSocket *> mSocket;
public slots:
};

#endif // SSLSERVER_H
