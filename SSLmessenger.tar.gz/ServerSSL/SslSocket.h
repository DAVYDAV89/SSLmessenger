#ifndef SSLSOCKET_H
#define SSLSOCKET_H

#include <QSslSocket>


class SslSocket : public QSslSocket
{
    Q_OBJECT
public:
    SslSocket();

signals:
    void    signal_encrypted();
    void    signal_ReadyRead(SslSocket *);
    void    signal_stateChanged(SslSocket *, int);
};

#endif // SSLSOCKET_H
