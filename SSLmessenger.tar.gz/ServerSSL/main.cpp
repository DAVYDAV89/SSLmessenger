#include <QCoreApplication>
#include <QFile>
#include <QDebug>
#include "SslServer.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QString str;
    QFile setPort("../ServerSSL/setPort.conf");
    if ( (setPort.exists()) && (setPort.open(QIODevice::ReadOnly) ) ){

        while(!setPort.atEnd())
        {
            str += setPort.readLine();
        }
        setPort.close();
    }

    quint16 port;
    QStringList arguments = str.split("port:", QString::SkipEmptyParts);
    for (auto el : arguments) {
        port = el.toUInt();
    }

    qDebug() << "setPort: " << port;

    SslServer Server;
    if (!Server.startServer(port)){
        qDebug() << "Error: " << Server.errorString();
        return 1;
    }
    qDebug() << "Server started..." ;

    return a.exec();
}
